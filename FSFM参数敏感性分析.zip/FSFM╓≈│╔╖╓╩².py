import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from matplotlib.font_manager import FontProperties

font = FontProperties(fname='simhei.ttf', size=14)

YEAR = '2023'
Month = '05'
Day = '15'

df0 = pd.read_csv(fr'..\NEWDATA\FSFM-com2\{YEAR}_{Month}_{Day}.csv')
df1 = pd.read_csv(fr'..\NEWDATA\FSFM-com4\{YEAR}_{Month}_{Day}.csv')
df2 = pd.read_csv(fr'..\NEWDATA\FSFM-com6\{YEAR}_{Month}_{Day}.csv')
df3 = pd.read_csv(fr'..\NEWDATA\FSFM-com8\{YEAR}_{Month}_{Day}.csv')
df4 = pd.read_csv(fr'..\NEWDATA\FSFM-com10\{YEAR}_{Month}_{Day}.csv')
df5 = pd.read_csv(fr'..\NEWDATA\FSFM-com15\{YEAR}_{Month}_{Day}.csv')
df6 = pd.read_csv(fr'..\NEWDATA\FSFM-com20\{YEAR}_{Month}_{Day}.csv')
df7 = pd.read_csv(fr'..\NEWDATA\FSFM-com25\{YEAR}_{Month}_{Day}.csv')
df8 = pd.read_csv(fr'..\NEWDATA\FSFM-com30\{YEAR}_{Month}_{Day}.csv')
df9 = pd.read_csv(fr'..\NEWDATA\FSFM-com40\{YEAR}_{Month}_{Day}.csv')
df10 = pd.read_csv(fr'..\NEWDATA\FSFM-com50\{YEAR}_{Month}_{Day}.csv')

dfNIRVP = pd.read_csv(fr'..\NEWDATA\NIRVP\{YEAR}_{Month}_{Day}.csv')

hours = dfNIRVP['Time'].values
for i in range(len(hours)):
    hours[i] = hours[i].split(':')
hour = np.zeros(len(hours))
for i in range(len(hours)):
    hour[i] = int(hours[i][0]) + int(hours[i][1]) / 60 + int(hours[i][2]) / 3600

rlist = np.zeros(11)
rmselist = np.zeros(11)
for i in range(0, 11):
    testlabel = dfNIRVP['NIRVP'].values * 10 / np.pi
    y_predicted = eval(f'df{i}')['FSFM'] * 10
    r = pearsonr(testlabel, y_predicted)[0]
    rmse = np.sqrt(np.mean((y_predicted - testlabel) ** 2))
    rlist[i] = r
    rmselist[i] = rmse

print(rlist, rmselist)

fig, ax = plt.subplots(figsize=(8, 6))
ax2 = ax.twinx()
line1, = ax.plot(np.arange(0, 11, 1), rlist, color='red', label='r', marker='o')
line2, = ax2.plot(np.arange(0, 11, 1), rmselist, color='blue', label='RMSE', marker='o')
ax.set_xlabel('PCs', fontsize=14)
ax.set_ylabel('r', fontsize=14)
ax2.set_ylabel('RMSE(mW/m\u00b2/nm/sr)', fontsize=14)
plt.xticks(np.arange(0, 11, 1), ['2', '4', '6', '8', '10', '15', '20', '25', '30', '40', '50'])
ax.tick_params(axis='x', labelsize=14)
ax.tick_params(axis='y', labelsize=14)
ax2.tick_params(axis='y', labelsize=14)
ax.set_ylim(0.6, 0.8)
ax.set_yticks([0.6, 0.65, 0.7, 0.75, 0.8])
ax2.set_ylim(7.6, 7.9)
ax2.set_yticks([7.6, 7.7, 7.8, 7.9])
lines = [line1, line2]
labels = [line.get_label() for line in lines]
ax.legend(lines, labels, loc='lower right', fontsize=20, frameon=False)
plt.savefig('jpg/FSFM-com.png', dpi=300)
plt.show()
